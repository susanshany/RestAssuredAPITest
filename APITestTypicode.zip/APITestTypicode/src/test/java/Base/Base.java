package Base;

public class Base {
    public String endpoint = "https://jsonplaceholder.typicode.com/users";
}
